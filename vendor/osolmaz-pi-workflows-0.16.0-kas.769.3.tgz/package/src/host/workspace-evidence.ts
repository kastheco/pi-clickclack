import { createHash } from "node:crypto";
import { readFileSync, realpathSync } from "node:fs";
import { fileURLToPath } from "node:url";
import type { StateDatabase } from "../state/database.js";
import type { ChangedFiles } from "../state/workspace-evidence.js";
import type { LoadedWorkflowRun } from "../workflows/store.js";
import type { WorkflowMountedSource } from "../workflows/types.js";
import {
  collectWorkspaceGit,
  prepareWorkspaceGit,
  type WorkspaceGitReceipt,
} from "./workspace-git.js";

function packagePreparation(source: WorkflowMountedSource["source"]): boolean {
  if (source.kind !== "file") return false;
  for (const extension of ["js", "ts"]) {
    try {
      const own = realpathSync(
        fileURLToPath(
          new URL(`../builtins/workspace-preparation.workflow.${extension}`, import.meta.url),
        ),
      );
      if (
        source.path === own &&
        source.hash === createHash("sha256").update(readFileSync(own)).digest("hex")
      )
        return true;
    } catch {
      /* Only the package's actual source/build file is eligible. */
    }
  }
  return false;
}

/** Host queue sources, not worker-provided outputs, establish the preparation implementation. */
export function eligibleWorkspaceAttempt(
  loaded: LoadedWorkflowRun,
  sources: unknown,
  attemptId: string | undefined,
): boolean {
  if (
    !attemptId ||
    loaded.state.currentAttemptId !== attemptId ||
    loaded.state.status !== "running"
  )
    return false;
  const node = loaded.snapshot.nodes[loaded.state.currentNode ?? ""];
  if (
    !node ||
    node.nodeType !== "action" ||
    !["inspect", "apply"].includes(node.localNodeId ?? loaded.state.currentNode ?? "")
  )
    return false;
  const value = sources as {
    root?: WorkflowMountedSource["source"];
    mounted?: WorkflowMountedSource[];
  } | null;
  if (!value || !Array.isArray(value.mounted)) return false;
  const mount = node.mountPath ?? [];
  const source =
    mount.length === 0
      ? value.root
      : value.mounted.find((entry) => JSON.stringify(entry.mountPath) === JSON.stringify(mount))
          ?.source;
  return source !== undefined && packagePreparation(source);
}

export function registerWorkspaceGit(
  state: StateDatabase,
  runId: string,
  attemptId: string,
  root: string,
  baseRevision: string,
): void {
  // Never replace a baseline. Multiple workspace/base registrations are unsupported.
  const existing = state.connection
    .prepare("SELECT receipt_json AS receipt FROM workspace_git_evidence WHERE run_id = ?")
    .get(runId) as { receipt: string } | undefined;
  if (existing) {
    const original = JSON.parse(existing.receipt) as WorkspaceGitReceipt | null;
    if (original?.root !== root || original?.baseRevision !== baseRevision) {
      // A permanent private tombstone; the visible value changes only with the next snapshot.
      state.connection
        .prepare("UPDATE workspace_git_evidence SET receipt_json = 'null' WHERE run_id = ?")
        .run(runId);
    }
    return;
  }
  const receipt = prepareWorkspaceGit(root, baseRevision);
  if (!receipt) return;
  state.connection
    .prepare(
      "INSERT INTO workspace_git_evidence(run_id, attempt_id, receipt_json) VALUES (?, ?, ?)",
    )
    .run(runId, attemptId, JSON.stringify(receipt));
}

/** Called within the same transaction as the host snapshot and presentation revision. */
export function refreshWorkspaceGit(state: StateDatabase, runId: string): void {
  const row = state.connection
    .prepare("SELECT receipt_json AS receipt FROM workspace_git_evidence WHERE run_id = ?")
    .get(runId) as { receipt: string } | undefined;
  if (!row) return;
  let files: ChangedFiles | null = null;
  try {
    files = collectWorkspaceGit(JSON.parse(row.receipt) as WorkspaceGitReceipt);
  } catch {
    /* Unavailable, not clean. */
  }
  state.connection
    .prepare("UPDATE workspace_git_evidence SET files_json = ? WHERE run_id = ?")
    .run(files === null ? null : JSON.stringify(files), runId);
}

export function readWorkspaceGit(state: StateDatabase, runId: string): ChangedFiles | null {
  const row = state.connection
    .prepare("SELECT files_json AS files FROM workspace_git_evidence WHERE run_id = ?")
    .get(runId) as { files: string | null } | undefined;
  return row?.files ? (JSON.parse(row.files) as ChangedFiles) : null;
}
