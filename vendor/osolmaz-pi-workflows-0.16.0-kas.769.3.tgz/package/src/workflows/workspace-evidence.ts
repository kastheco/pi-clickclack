import type { WorkflowActionContext } from "./types.js";

/** Internal capability; never serialized into workflow state or agent requests. */
export type WorkspaceEvidenceRegistration = { root: string; baseRevision: string };
type Register = (value: WorkspaceEvidenceRegistration) => Promise<void>;
// Symbol.for spans the native engine and the isolated jiti workflow loader.
const capability = Symbol.for("pi-workflows.internal.workspace-evidence");
type EvidenceContext = WorkflowActionContext & { [capability]?: Register };

export function bindWorkspaceEvidence(context: WorkflowActionContext, register: Register): void {
  Object.defineProperty(context, capability, { value: register });
}

export function projectWorkspaceEvidence(
  from: WorkflowActionContext,
  to: WorkflowActionContext,
): WorkflowActionContext {
  const register = (from as EvidenceContext)[capability];
  if (register) bindWorkspaceEvidence(to, register);
  return to;
}

export async function registerWorkspaceEvidence(
  context: WorkflowActionContext,
  value: WorkspaceEvidenceRegistration,
): Promise<void> {
  await (context as EvidenceContext)[capability]?.(value);
}
