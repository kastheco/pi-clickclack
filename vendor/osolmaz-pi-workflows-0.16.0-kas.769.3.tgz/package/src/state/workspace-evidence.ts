/** Operator metadata bounds are required by clickclack.workflow-snapshot.v1. */
export type ChangedFiles = {
  source: "host-git";
  basis: "cumulative-since-base";
  baseRevision: string;
  attribution: "clean-baseline" | "includes-preexisting-changes";
  complete: boolean;
  truncated: boolean;
  entries: ChangedFile[];
};
export type ChangedFile = {
  path: string;
  change:
    | "added"
    | "modified"
    | "deleted"
    | "renamed"
    | "copied"
    | "type_changed"
    | "unmerged"
    | "untracked";
  oldPath?: string;
};
