import type { StateDatabase } from "../state/database.js";

/** Restart-created attempts/revisions are not progress. Only durable completed
 * nodes, a non-crash worker checkpoint, or an accepted user resume reset budget. */
export function runnerCrashBudgetExhausted(state: StateDatabase, runId: string): boolean {
  const row = state.connection
    .prepare(`
    SELECT max(boundary) AS boundary FROM (
      SELECT coalesce(max(finished_at), 0) AS boundary FROM node_attempts
      WHERE run_id = ? AND status = 'completed'
      UNION ALL
      SELECT coalesce(max(completed_at), 0) AS boundary FROM host_commands
      WHERE run_id = ? AND operation = 'run.resume' AND outcome = 'accepted'
    )`)
    .get(runId, runId) as { boundary: number };
  const workers = state.connection
    .prepare(`
    SELECT status FROM run_workers WHERE run_id = ? AND started_at >= ?
    ORDER BY started_at DESC, rowid DESC LIMIT 3`)
    .all(runId, row.boundary) as { status: string }[];
  return workers.length === 3 && workers.every((worker) => worker.status === "crashed");
}
