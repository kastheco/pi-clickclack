import { createHash, randomUUID } from "node:crypto";
import type { StateDatabase } from "../state/database.js";
import { canonicalJson, parseJson, type JsonValue } from "../state/json.js";
import {
  encodeRunnerLine,
  isRunnerContentReference,
  WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES,
  WORKFLOW_RUNNER_CONTENT_REFERENCE_SCHEMA,
  type WorkflowRunnerMessage,
  type WorkflowRunnerResponse,
  type WorkflowRunnerContentReference,
} from "./workflow-runner-protocol.js";

export const MAX_RUNNER_UPLOAD_BYTES = 64 * 1024 * 1024;
export const MAX_RUNNER_UPLOADS = 8;
export const RUNNER_UPLOAD_TTL_MS = 60_000;
export type RunnerPayloadReference = WorkflowRunnerContentReference & { uploadId: string };
type Binding = {
  runId: string;
  runnerEpoch: string;
  generation: number;
  expectedRevision: number;
  claimToken: string;
};
type Upload = {
  binding: string;
  reference: RunnerPayloadReference;
  parts: Buffer[];
  offset: number;
  expiresAt: number;
  timer: ReturnType<typeof setTimeout>;
  complete: boolean;
};

/** Bounded ephemeral authorization/staging; only verified complete JSON enters durable blobs. */
export class RunnerPayloadUploads {
  private readonly uploads = new Map<string, Upload>();
  private reservedBytes = 0;
  constructor(
    private readonly state: StateDatabase,
    private readonly now = Date.now,
  ) {}

  private key(binding: Binding, uploadId: string): string {
    return canonicalJson([binding.runnerEpoch, uploadId]);
  }
  private remove(key: string): void {
    const upload = this.uploads.get(key);
    if (!upload) return;
    clearTimeout(upload.timer);
    this.reservedBytes -= upload.reference.bytes;
    this.uploads.delete(key);
  }
  clearEpoch(runnerEpoch: string): void {
    for (const [key, upload] of this.uploads) {
      if ((JSON.parse(upload.binding) as Binding).runnerEpoch === runnerEpoch) this.remove(key);
    }
  }
  private sweep(): void {
    for (const [key, upload] of this.uploads) if (upload.expiresAt <= this.now()) this.remove(key);
  }
  write(binding: Binding, payload: JsonValue): RunnerPayloadReference | null {
    this.sweep();
    if (typeof payload !== "object" || payload === null || Array.isArray(payload))
      throw new Error("Invalid runner upload chunk");
    const { uploadId, sha256, bytes, offset, data } = payload;
    if (
      typeof uploadId !== "string" ||
      !/^[a-zA-Z0-9-]{1,128}$/u.test(uploadId) ||
      typeof sha256 !== "string" ||
      !/^[0-9a-f]{64}$/u.test(sha256) ||
      typeof bytes !== "number" ||
      !Number.isSafeInteger(bytes) ||
      bytes <= 0 ||
      bytes > MAX_RUNNER_UPLOAD_BYTES ||
      typeof offset !== "number" ||
      !Number.isSafeInteger(offset) ||
      offset < 0 ||
      typeof data !== "string" ||
      data.length > Math.ceil((WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES * 4) / 3)
    )
      throw new Error("Invalid runner upload bounds");
    const part = Buffer.from(data, "base64url");
    if (
      part.toString("base64url") !== data ||
      part.length === 0 ||
      part.length > WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES ||
      offset % WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES !== 0 ||
      offset + part.length > bytes ||
      (offset + part.length < bytes && part.length !== WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES)
    )
      throw new Error("Invalid runner upload chunk framing");
    const key = this.key(binding, uploadId);
    let upload = this.uploads.get(key);
    if (!upload) {
      if (offset !== 0) throw new Error("Runner upload is missing or expired");
      if (
        this.uploads.size >= MAX_RUNNER_UPLOADS ||
        this.reservedBytes + bytes > MAX_RUNNER_UPLOAD_BYTES
      )
        throw new Error("Runner upload staging limit exceeded");
      const timer = setTimeout(() => this.remove(key), RUNNER_UPLOAD_TTL_MS);
      timer.unref();
      upload = {
        binding: canonicalJson(binding),
        reference: {
          schema: WORKFLOW_RUNNER_CONTENT_REFERENCE_SCHEMA,
          uploadId,
          sha256,
          bytes,
          mediaType: "application/json",
        },
        parts: [],
        offset: 0,
        expiresAt: this.now() + RUNNER_UPLOAD_TTL_MS,
        timer,
        complete: false,
      };
      this.uploads.set(key, upload);
      this.reservedBytes += bytes;
    }
    if (
      upload.binding !== canonicalJson(binding) ||
      upload.reference.sha256 !== sha256 ||
      upload.reference.bytes !== bytes
    )
      throw new Error("Runner upload binding conflict");
    if (offset < upload.offset) {
      const prior = upload.complete
        ? this.state
            .readBlob(Buffer.from(sha256, "hex"))
            ?.content.subarray(offset, offset + part.length)
        : upload.parts[offset / WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES];
      if (!prior?.equals(part)) throw new Error("Runner upload duplicate chunk conflict");
      return upload.complete ? upload.reference : null;
    }
    if (offset !== upload.offset) throw new Error("Runner upload chunk is out of order");
    upload.parts.push(part);
    upload.offset += part.length;
    if (upload.offset !== bytes) return null;
    try {
      const content = Buffer.concat(upload.parts, bytes);
      if (createHash("sha256").update(content).digest("hex") !== sha256)
        throw new Error("Runner upload digest mismatch");
      parseJson(content.toString("utf8"));
      this.state.putBlob(content, "application/json");
      upload.complete = true;
      upload.parts = [];
      return upload.reference;
    } catch (error) {
      this.remove(key);
      throw error;
    }
  }
  resolve(binding: Binding, reference: RunnerPayloadReference): JsonValue {
    this.sweep();
    const upload = this.uploads.get(this.key(binding, reference.uploadId));
    if (
      !upload?.complete ||
      upload.binding !== canonicalJson(binding) ||
      canonicalJson(upload.reference) !== canonicalJson(reference)
    )
      throw new Error("Runner payload reference is missing, foreign or expired");
    const stored = this.state.readBlob(Buffer.from(reference.sha256, "hex"));
    if (
      !stored ||
      stored.byteLength !== reference.bytes ||
      stored.mediaType !== reference.mediaType ||
      createHash("sha256").update(stored.content).digest("hex") !== reference.sha256
    )
      throw new Error("Runner payload blob is unavailable or corrupt");
    const payload = parseJson(stored.content.toString("utf8"));
    // Once dispatched, normal worker-message receipts own replay. Staging is
    // single-use and must not reserve capacity for the rest of the epoch.
    this.remove(this.key(binding, reference.uploadId));
    return payload;
  }
}

export async function sendRunnerPayload(
  message: WorkflowRunnerMessage,
  send: (message: WorkflowRunnerMessage) => Promise<WorkflowRunnerResponse>,
): Promise<WorkflowRunnerResponse> {
  try {
    encodeRunnerLine(message);
  } catch {
    const content = Buffer.from(canonicalJson(message.payload), "utf8");
    if (content.length > MAX_RUNNER_UPLOAD_BYTES)
      throw new Error("Runner payload exceeds 64 MiB upload limit");
    const reference: RunnerPayloadReference = {
      schema: WORKFLOW_RUNNER_CONTENT_REFERENCE_SCHEMA,
      uploadId: randomUUID(),
      sha256: createHash("sha256").update(content).digest("hex"),
      bytes: content.length,
      mediaType: "application/json",
    };
    const referenced: WorkflowRunnerMessage = {
      ...message,
      payload: {},
      payloadReference: reference,
    };
    encodeRunnerLine(referenced);
    for (let offset = 0; offset < content.length; offset += WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES) {
      const response = await send({
        ...message,
        messageId: randomUUID(),
        kind: "runner.progress",
        operation: "content.write",
        payload: {
          uploadId: reference.uploadId,
          sha256: reference.sha256,
          bytes: content.length,
          offset,
          data: content
            .subarray(offset, offset + WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES)
            .toString("base64url"),
        },
      });
      if (response.outcome === "rejected" || response.outcome === "claimLost")
        return { ...response, messageId: message.messageId };
      if (response.outcome !== "accepted")
        throw new Error("Unexpected runner upload acknowledgment");
      if (
        offset + WORKFLOW_RUNNER_CONTENT_CHUNK_BYTES >= content.length &&
        (!isRunnerContentReference(response.result) ||
          canonicalJson(response.result) !== canonicalJson(reference))
      )
        throw new Error("Runner upload completion reference mismatch");
    }
    return await send(referenced);
  }
  return await send(message);
}
