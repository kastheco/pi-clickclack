/** A source-load failure is retryable only by explicit origin-session recovery. */
export function isRecoverableWorkflowLoadFailure(run: {
  status: string;
  errorCode: string | null;
  executionMode: string;
}): boolean {
  return (
    run.status === "failed" &&
    run.errorCode === "workflowLoadFailed" &&
    run.executionMode === "interactive"
  );
}
