import { isDeepStrictEqual } from "node:util";
import type { WorkflowSource, WorkflowMountedSource } from "./types.js";

/** Only the installation prefix may change; content and package-relative identity stay pinned. */
export function isRelocatedPackageSource(saved: WorkflowSource, current: WorkflowSource): boolean {
  if (saved.kind !== "file" || current.kind !== "file") return false;
  if (!/^[a-f0-9]{64}$/.test(saved.hash) || saved.hash !== current.hash) return false;
  const packageFile =
    /^(?:\/[^/]+)+\/node_modules\/@osolmaz\/pi-workflows\/(dist\/builtins\/[^/]+\.workflow\.js)$/;
  const savedFile = packageFile.exec(saved.path)?.[1];
  return savedFile !== undefined && savedFile === packageFile.exec(current.path)?.[1];
}

export function mountedWorkflowSourcesEqual(
  saved: WorkflowMountedSource[],
  current: WorkflowMountedSource[],
): boolean {
  const sort = (sources: WorkflowMountedSource[]) =>
    [...sources].sort((a, b) => a.mountPath.join("/").localeCompare(b.mountPath.join("/")));
  const observed = sort(current);
  return (
    saved.length === current.length &&
    sort(saved).every((entry, index) => {
      const next = observed[index]!;
      return (
        isDeepStrictEqual(entry, next) ||
        (isDeepStrictEqual(entry.mountPath, next.mountPath) &&
          entry.workflowName === next.workflowName &&
          isRelocatedPackageSource(entry.source, next.source))
      );
    })
  );
}

export function workflowSourcesEqual(
  saved: { root: WorkflowSource; mounted: WorkflowMountedSource[] },
  current: { root: WorkflowSource; mounted: WorkflowMountedSource[] },
): boolean {
  return (
    isDeepStrictEqual(saved.root, current.root) &&
    mountedWorkflowSourcesEqual(saved.mounted, current.mounted)
  );
}
