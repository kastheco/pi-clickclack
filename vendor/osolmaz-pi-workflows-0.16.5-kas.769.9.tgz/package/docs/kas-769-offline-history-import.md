# Offline history import: candidate evidence and cutover gates

Status: implemented and tested in isolated worktrees; **not live**. Independent review is required. No fresh-empty-state/archive-only cutover is proposed.

## Candidate contracts

- Source: installed `0.16.0-kas.769.3`, schema SQL SHA256 `746e675ea021ca69a87e640c726e279c8864d16b64819b0d2802eb2d7ea97ccf`. The SQL fixture is the exact installed schema, not a reconstructed digest.
- Target: upstream `v0.16.5` plus retained customizations, external presenter subscription, and offline historical import fences; version `0.16.5-kas.769.7`.
- Import CLI: `node scripts/migration/import-0160-history.mjs SOURCE.sqlite NEW_OUTPUT.sqlite`. Requires a supported inactive backup, enough free disk space, and a nonexistent output path. Never point it at the active database. Do not change `PI_WORKFLOWS_STATE_PATH` to the backup.
- The source is opened read-only and attested before/after. The fresh target gets the genuine current schema/digest. Unchanged tables are copied exactly; original rows from changed/removed tables are preserved in typed `imported_history_records`. Original run snapshots, effects, keys, payload/result blobs and receipts survive; no old execution is replayed.
- Pending effects are historical only. Nonterminal/dispatchable work, owned leases, active workers/deliveries/follow-ups, resource-manager state and unknown parent lineage are rejected, not silently normalized. This is deliberately not a general hot migration.
- Output publication is exclusive, through same-directory staging; `<output>.report.json` includes hashes. An identical rerun verifies the untouched output and returns the same report. Changed output, mismatched source/schema, or unsupported state fails closed. The verified pristine output must stay unused; test rendering on a separate copy because view-content caching writes are normal.
- Imported run rows/resources/blobs and audit records are protected. Imported runs cannot resume, adopt effects, acquire explicit claims, mutate history, fork or continue. Views identify read-only history and expose no run controls. Starting a new independent task remains supported.

## Executed backup-copy evidence

The prior installed package's supported backup produced the sealed source; its database was never modified. Only inactive copies were read/imported.

```
/tmp/piw-migration-753/sealed-source.sqlite
SHA256 80f50893ee8706f65fe65d6d68804f731689fc13def7bb1bf33ae9d06d469a48
/tmp/piw-migration-753/candidate-v6.sqlite
SHA256 922eebc0a698a75b09e5083614c1dedc1c48b7fd742b838bb6b8f4090f3cbe67
```

Executed from the candidate worktree:

```sh
node scripts/migration/import-0160-history.mjs \
  /tmp/piw-migration-753/sealed-source.sqlite \
  /tmp/piw-migration-753/candidate-v6.sqlite
# Same command repeated successfully: unchanged-output idempotency.
```

Reports: `/tmp/piw-7696-sealed-import.log`, `/tmp/piw-7696-sealed-repeat.log`, `candidate-v6.sqlite.report.json`. All source table counts and every copied-cell equality are checked by the importer; canonical projections intentionally omit five obsolete coordinator/follow-up resources and their five leases/five events, and 14 old coordinator commands, while retaining their complete source rows in provenance. blob content hashes, integrity and foreign keys are checked. There are four imported runs, 13,668 blobs, 15 effect rows (11 applied, four pending). Original failure/status history is not rewritten.

A separate `boot-check-v6.sqlite` copy exercised latest `ServerViewStore.run()` for all four runs. `/tmp/piw-7696-sealed-boot.log` records historical/read-only flags, empty controls, original reasons, and integrity `ok`:

| Run                                                  | Original status | Steps |
| ---------------------------------------------------- | --------------- | ----- |
| `20260904T222920957Z-orkastrator-cook-6b5c54cb`      | failed          | 43    |
| `20260905T000432835Z-orkastrator-cook-906e4b81`      | timed_out       | 1     |
| `20260905T215247825Z-orkastrator-implement-b0aab933` | completed       | 46    |
| `20260905T215835045Z-orkastrator-implement-a0a8960e` | failed          | 16    |

The last failure still reads “Managed effect key was reused with another request.” It is not resumed under the new identity algorithm; a new lifecycle must be launched after approved cutover.

## Verification

- Host: build/typecheck/lint passed; 105 suites, 1,213 tests; statements 90.99%, branches 85.32%, functions 95.04%, lines 92.56%. Logs `/tmp/piw-final-{typecheck,lint,tests}.log`.
- `offline-history-import.test.ts`: ten tests cover byte/receipt preservation, schema/digest drift rejection, interrupted/unsupported inputs, idempotency/output corruption, immutable historical writes/effect adoption/claims/resume and successful fresh execution.
- `external-presenter-subscription.test.ts` and `extension.test.ts`: external takeover cancels actual presenter; coordinator replacement/stale answers remain fenced; same-session subscriptions persist until last unsubscribe/disconnect, reconnect restores presence, other sessions are isolated, combined coordinator/external role is rejected.
- Bridge: full build/test suite, 216 tests. Source-named tests exercise cancellation/revision fencing, deterministic publication nonce, distinct destination/producer/host/run/request/revision, independent simultaneous instances and a restarted instance for both DM and channel. Multi-instance publication uses a fixture of the existing API nonce contract, not a live-app test. Log `/tmp/bridge-all-tests.log`.
- Actual ClickClack SQLite nonce contract: `go test ./apps/api/internal/store/sqlite -run 'TestStoreChatThreadsSearchUploadsAndEvents|TestMessagePrivacyScalingPrivacyAndDMThreads' -count=1` passed, log `/tmp/clickclack-nonce-proof.log`. `schema.sql` has unique `messages(author_id, client_nonce)` for nonempty nonce. Duplicate equivalent requests return the existing message with no new event; changed payload conflicts. `sqlite/helpers.go` limits nonce to 128 Unicode characters; the candidate nonce is 76 ASCII characters.

## Parent-only cutover sequence (not executed)

1. Independently review all three consumers and this offline importer. Refresh Orkastrator's bundle/integrity manifest to the **same final** host tarball as pi-clickclack; the prior `.769.4` bundle is not suitable for this migration. Re-run its consumer/release checks. Verify that installed consumers will all load the same host schema and subscription contract.
2. Record exact live package artifacts, manifests/locks, service commands, database path and backup destination. Use the installed old CLI's supported `state backup` and old-package verification. Resolve exact CLI paths and stop commands from the deployment environment rather than guessing. Stop all clients capable of autostart, then stop the old host (`host stop`, not latest `server stop`). Take/verify a final supported backup after quiescence; any newly nonterminal work blocks this importer.
3. Build/pack the final candidate. Run the import CLI above against the **final backup**, using a new private output location. Verify report, hashes, integrity and foreign keys; independently compare historical runs/receipts. Preserve a pristine imported copy; validate view rendering on another copy. Keep old package/database/WAL-SHM shutdown set together for rollback.
4. Only after explicit deployment approval, install all matching candidate consumers and publish the verified imported database at the approved state path while clients are stopped. Start the new server and clients once. Check server identity/schema, four historical views, inability to mutate old runs, ordinary new-task execution, external watcher lifecycle and one decision publication. Do not call the work deployed or ready for verification until the environment's completion checks pass.
5. Launch a **new** KAS-753 lifecycle through the supported workflow entrypoint; never resume the failed imported collision run.

Rollback: stop all new clients/server first; preserve the complete post-cutover database separately (do not overwrite new work). Restore the exact old package set and matching old database shutdown set together, then restart old clients. Never pair an old binary with the new schema. Exact environment-specific stop/install/start commands remain a parent deployment gate; no authorization to execute them was given.

## Independent-review corrections (.769.6)

- Imported terminal runs are excluded both from boot discovery and direct terminal-message reconciliation. An interactive-binding fixture asserts an empty retry queue across repeated discovery/reconciliation, no reconciliation-error logs on direct retries, and no newly created messages/turns. Live ambiguous/unsettled effect counters exclude imported resource IDs, while historical receipts remain queryable and unchanged. Existing imported applying-effect recovery is regression-tested to reject read-only history without changing status.
- Review finding about legacy `workflow_messages`/`workflow_turns` being copied was inaccurate: neither table exists in the pinned installed source SQL. The exact-source importer does not accept a new schema or query nonexistent tables. Legacy `turn_intents` with `resolved_at IS NULL` are the equivalent open work: old `src/controllers/sqlite.ts` selects them at lines 2224, 2276 and 2300, and records resolution at 2347. Such sources now fail closed. Settled intents remain in typed provenance; latest messages/turns remain empty. Existing pending-interaction/channel/notification guards remain.
- The sealed source has one resolved `presentation` intent, zero unresolved intents/pending interactions/channel messages/notifications. Inventory: `/tmp/piw-7696-sealed-inventory.log`. Its SHA256 is unchanged. Import and unchanged-output rerun passed. A separate `boot-check-v6.sqlite` copy was booted/reconciled with latest server code, without clients or model calls: zero retry entries/error logs/live effects/messages/turns; all four read-only historical run views rendered; integrity `ok`. Evidence: `/tmp/piw-7696-sealed-boot.log`.
- Every copied table now asserts filtered-source row count equals canonical row count before publication, in addition to existing bidirectional common-cell equality. The report exposes `filteredSourceCounts`. Fixtures cover unchanged-table equality and obsolete-resource filtering (source three, copied two, original provenance retained).
- External presentation uses the existing same-local-user Unix socket trust boundary. Socket clients can subscribe to arbitrary sessions and submit external answers. The bridge's external-presenter flag is a cooperation convention, not per-session authenticated ownership. Coordinator epoch/connection and revision checks are still enforced. No auth subsystem was added; the test name and upgrade document no longer imply one.
- Host `npm run check`: 105 suites, 1,213 tests, statements 90.99%, branches 85.32%, functions 95.04%, lines 92.56%; `/tmp/piw-7696-check.log`. Red evidence: `/tmp/piw-7696-red.log`, `red-counts.log`, `red-direct.log`. Bridge bounded-page omission/reappearance of the same revision now cancels stale presentation and releases its dedup key; `/tmp/bridge-7696-{red,green}.log`.
- ClickClack nonce contract rechecked offline, not via live message publication: SQLite schema unique index on `(author_id, client_nonce)`, helper limit 128 Unicode characters, existing duplicate/conflicting DM/channel tests passed. Log `/tmp/piw-7696-nonce-contract.log`. Candidate nonce remains 76 ASCII characters.

All evidence is candidate-only. A fresh final supported backup, successful import and independent re-review remain mandatory before any cutover.
