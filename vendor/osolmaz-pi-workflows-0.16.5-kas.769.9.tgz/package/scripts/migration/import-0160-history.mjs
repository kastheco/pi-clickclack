import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import {
  createReadStream,
  existsSync,
  linkSync,
  mkdtempSync,
  readFileSync,
  realpathSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import Database from "better-sqlite3";
import { StateDatabase, workflowStatePath } from "../../dist/state/database.js";

const SOURCE_VERSION = "0.16.0-kas.769.3";
const SOURCE_SCHEMA_SHA256 = "746e675ea021ca69a87e640c726e279c8864d16b64819b0d2802eb2d7ea97ccf";
const q = (name) => `"${name.replaceAll('"', '""')}"`;
async function digestFile(file) {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest("hex");
}
function shape(db) {
  return db
    .prepare(
      "SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name",
    )
    .all();
}
function typedRow(row) {
  return Object.fromEntries(
    Object.entries(row).map(([key, value]) => [
      key,
      Buffer.isBuffer(value)
        ? { type: "blob", hex: value.toString("hex") }
        : typeof value === "bigint"
          ? { type: "integer", decimal: String(value) }
          : { type: "value", value },
    ]),
  );
}

/** Offline-only, exact-source, terminal-history import. Neither source nor receipts are rewritten. */
export async function importHistory(sourcePath, outputPath) {
  const source = realpathSync(sourcePath);
  const output = resolve(outputPath);
  if (
    source === resolve(workflowStatePath()) ||
    (existsSync(workflowStatePath()) && source === realpathSync(workflowStatePath()))
  )
    throw new Error("Use a supported inactive backup, never the active database");
  if (source === output || (existsSync(`${source}-wal`) && statSync(`${source}-wal`).size > 0))
    throw new Error("Source must be an inactive standalone backup without WAL/SHM");
  const sourceHash = await digestFile(source);
  const sourceHashBytes = Buffer.from(sourceHash, "hex");
  if (existsSync(output)) {
    const attestation = JSON.parse(readFileSync(`${output}.report.json`, "utf8"));
    assert.equal(
      attestation.outputHash,
      await digestFile(output),
      "Previously imported output changed",
    );
    const prior = new StateDatabase({ filePath: output, mode: "read-only" });
    try {
      const row = prior.connection
        .prepare("SELECT report_json FROM imported_history WHERE source_hash = ?")
        .get(sourceHashBytes);
      if (!row) throw new Error("Output already exists and is not this verified import");
      prior.integrityCheck();
      return JSON.parse(row.report_json);
    } finally {
      prior.close();
    }
  }
  const sourceSql = readFileSync(new URL("installed-0160-kas7693.sql", import.meta.url), "utf8");
  assert.equal(createHash("sha256").update(sourceSql).digest("hex"), SOURCE_SCHEMA_SHA256);
  const legacy = new Database(source, { readonly: true, fileMustExist: true });
  legacy.pragma("query_only = ON");
  const expected = new Database(":memory:");
  expected.exec(sourceSql);
  let staging;
  let target;
  try {
    assert.deepEqual(shape(legacy), shape(expected), "Unsupported source schema shape");
    const meta = legacy.prepare("SELECT * FROM schema_meta WHERE id=1").get();
    assert.equal(
      meta.schema_digest.toString("hex"),
      SOURCE_SCHEMA_SHA256,
      "Unsupported source schema digest",
    );
    assert.equal(legacy.pragma("application_id", { simple: true }), 0x50495746);
    assert.equal(legacy.pragma("user_version", { simple: true }), 1);
    assert.equal(legacy.pragma("integrity_check", { simple: true }), "ok");
    assert.deepEqual(legacy.pragma("foreign_key_check"), []);
    const nonempty = (sql) => legacy.prepare(sql).get();
    if (
      nonempty(
        "SELECT 1 FROM runs WHERE status NOT IN ('completed','failed','timed_out','cancelled')",
      )
    )
      throw new Error("Nonterminal runs require a separately supported migration");
    if (nonempty("SELECT 1 FROM run_queue WHERE status NOT IN ('done','failed','cancelled')"))
      throw new Error("Dispatchable queue entries are unsupported");
    if (nonempty("SELECT 1 FROM leases WHERE owner_id IS NOT NULL"))
      throw new Error("Owned resource leases are unsupported");
    if (nonempty("SELECT 1 FROM run_workers WHERE status NOT IN ('exited','crashed','cancelled')"))
      throw new Error("Live workers are unsupported");
    if (nonempty("SELECT 1 FROM interactive_requests WHERE status NOT IN ('settled','cancelled')"))
      throw new Error("Pending interactions are unsupported");
    for (const table of [
      "notifications",
      "channel_inbox",
      "channel_messages",
      "channel_message_parts",
      "workflow_follow_ups",
    ]) {
      if (nonempty(`SELECT 1 FROM ${q(table)}`))
        throw new Error(
          `Delivery/followup history in ${table} requires a separately supported mapping`,
        );
    }
    if (
      nonempty(
        "SELECT 1 FROM effects e LEFT JOIN runs r ON r.resource_id=e.source_resource_id WHERE r.run_id IS NULL",
      )
    )
      throw new Error("Effects not owned by a fenced terminal run are unsupported");
    for (const table of ["controller_resources", "controller_queue"]) {
      if (nonempty(`SELECT 1 FROM ${q(table)}`))
        throw new Error("Resource-manager state requires a separately supported migration");
    }
    if (
      nonempty(
        "SELECT 1 FROM runs r WHERE parent_run_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM continuations c WHERE c.parent_run_id=r.parent_run_id AND c.continuation_run_id=r.run_id)",
      )
    )
      throw new Error("Unknown legacy parent lineage");
    if (nonempty("SELECT 1 FROM turn_intents WHERE resolved_at IS NULL"))
      throw new Error("Unresolved legacy turn intents require a separately supported migration");
    const runs = legacy.prepare("SELECT * FROM runs ORDER BY created_at,run_id").all();
    const byId = new Map(runs.map((row) => [row.run_id, row]));
    const roots = new Map();
    for (const row of runs) {
      let current = row;
      const seen = new Set();
      while (current.parent_run_id !== null) {
        if (seen.has(current.run_id)) throw new Error("Cyclic run lineage");
        seen.add(current.run_id);
        current = byId.get(current.parent_run_id);
        if (!current) throw new Error("Missing parent run");
      }
      roots.set(row.run_id, current.run_id);
    }
    staging = mkdtempSync(join(dirname(output), ".piw-history-import-"));
    const stagedPath = join(staging, "state.sqlite");
    target = new StateDatabase({ filePath: stagedPath });
    const db = target.connection;
    db.pragma("foreign_keys = OFF");
    db.prepare("ATTACH DATABASE ? AS legacy").run(source);
    const sourceTables = legacy
      .prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
      .all()
      .map((row) => row.name);
    const targetTables = new Set(
      db
        .prepare("SELECT name FROM sqlite_master WHERE type='table'")
        .all()
        .map((row) => row.name),
    );
    const counts = {};
    const auditCounts = {};
    const canonicalCounts = {};
    const filteredSourceCounts = {};
    const copyFilters = {
      resources: "resource_type NOT IN ('notification','turn_intent','follow_up_queue')",
      leases:
        "resource_id IN (SELECT resource_id FROM legacy.resources WHERE resource_type NOT IN ('notification','turn_intent','follow_up_queue'))",
      events:
        "resource_id IN (SELECT resource_id FROM legacy.resources WHERE resource_type NOT IN ('notification','turn_intent','follow_up_queue'))",
      host_commands:
        "operation NOT IN ('host.status','host.stop','turn.claim','turn.resolve','notification.claim','notification.resolve','controller.list','controller.get','controller.apply','controller.reconcile','controller.delete')",
    };
    const auditTables = new Set([
      "workflow_host_state",
      "sqlite_sequence",
      "schema_meta",
      "runs",
      "resources",
      "leases",
      "events",
      "host_commands",
      "interactive_requests",
      "workflow_follow_ups",
      "channel_messages",
    ]);
    const audit = db.prepare("INSERT INTO imported_history_records VALUES (?,?,?,?)");
    db.transaction(() => {
      for (const table of sourceTables) {
        counts[table] = legacy.prepare(`SELECT count(*) AS count FROM ${q(table)}`).get().count;
        if (!targetTables.has(table) || auditTables.has(table)) {
          let index = 0;
          for (const row of legacy
            .prepare(`SELECT * FROM ${q(table)} ORDER BY rowid`)
            .safeIntegers()
            .iterate())
            audit.run(sourceHashBytes, table, index++, JSON.stringify(typedRow(row)));
          auditCounts[table] = index;
        }
        if (!targetTables.has(table) || table === "schema_meta") continue;
        if (table === "workflow_host_state") {
          db.prepare("UPDATE workflow_host_state SET epoch=? WHERE id=1").run(
            legacy.prepare("SELECT epoch FROM workflow_host_state WHERE id=1").get().epoch,
          );
          continue;
        }
        if (table === "sqlite_sequence") {
          for (const row of legacy.prepare("SELECT * FROM sqlite_sequence").all()) {
            if (!targetTables.has(row.name)) continue;
            const prior = db.prepare("SELECT seq FROM sqlite_sequence WHERE name=?").get(row.name);
            if (prior)
              db.prepare("UPDATE sqlite_sequence SET seq=max(seq,?) WHERE name=?").run(
                row.seq,
                row.name,
              );
            else db.prepare("INSERT INTO sqlite_sequence VALUES (?,?)").run(row.name, row.seq);
          }
          continue;
        }
        const oldColumns = legacy
          .prepare(`PRAGMA table_info(${q(table)})`)
          .all()
          .map((column) => column.name);
        const newColumns = new Set(
          db
            .prepare(`PRAGMA table_info(${q(table)})`)
            .all()
            .map((column) => column.name),
        );
        const common = oldColumns.filter((name) => newColumns.has(name));
        if (table === "runs") {
          const statement = db.prepare(
            `INSERT INTO runs (${common.map(q).join(",")},root_run_id,lineage_kind) VALUES (${common.map(() => "?").join(",")},?,?)`,
          );
          for (const row of runs)
            statement.run(
              ...common.map((key) => row[key]),
              roots.get(row.run_id),
              row.parent_run_id === null ? null : "continuation",
            );
        } else {
          const columns = common.map(q).join(",");
          db.exec(
            `INSERT INTO main.${q(table)} (${columns}) SELECT ${columns} FROM legacy.${q(table)}${copyFilters[table] ? ` WHERE ${copyFilters[table]}` : ""}`,
          );
        }
        canonicalCounts[table] = db
          .prepare(`SELECT count(*) AS count FROM main.${q(table)}`)
          .get().count;
        // Verify preserved common fields byte-for-byte, including every blob and effect receipt.
        const columns = common.map(q).join(",");
        const filtered = `SELECT ${columns} FROM legacy.${q(table)}${copyFilters[table] ? ` WHERE ${copyFilters[table]}` : ""}`;
        filteredSourceCounts[table] = db
          .prepare(`SELECT count(*) AS count FROM (${filtered})`)
          .get().count;
        assert.equal(
          canonicalCounts[table],
          filteredSourceCounts[table],
          `Copied row count mismatch: ${table}`,
        );
        assert.equal(
          db
            .prepare(
              `SELECT count(*) AS count FROM (${filtered} EXCEPT SELECT ${columns} FROM main.${q(table)})`,
            )
            .get().count,
          0,
          `Changed source values in ${table}`,
        );
        assert.equal(
          db
            .prepare(
              `SELECT count(*) AS count FROM (SELECT ${columns} FROM main.${q(table)} EXCEPT ${filtered})`,
            )
            .get().count,
          0,
          `Unexpected target values in ${table}`,
        );
      }
      const report = {
        schema: "pi-workflows.offline-history-import.v1",
        sourceVersion: SOURCE_VERSION,
        sourceHash,
        sourceSchemaDigest: SOURCE_SCHEMA_SHA256,
        runIds: runs.map((r) => r.run_id),
        sourceCounts: counts,
        canonicalCounts,
        filteredSourceCounts,
        auditCounts,
        readOnlyImportedRuns: true,
      };
      db.prepare("INSERT INTO imported_history VALUES (?,?,?,?,?)").run(
        sourceHashBytes,
        Buffer.from(SOURCE_SCHEMA_SHA256, "hex"),
        SOURCE_VERSION,
        JSON.stringify(report),
        Date.now(),
      );
      db.prepare("INSERT INTO imported_history_runs SELECT run_id,? FROM runs").run(
        sourceHashBytes,
      );
      db.prepare("INSERT INTO imported_history_resources SELECT resource_id,? FROM resources").run(
        sourceHashBytes,
      );
      db.prepare("INSERT INTO imported_history_blobs SELECT blob_hash,? FROM blobs").run(
        sourceHashBytes,
      );
    })();
    db.exec("DETACH DATABASE legacy");
    db.pragma("foreign_keys = ON");
    target.integrityCheck();
    assert.deepEqual(db.pragma("foreign_key_check"), []);
    const report = JSON.parse(
      db.prepare("SELECT report_json FROM imported_history").get().report_json,
    );
    db.pragma("wal_checkpoint(TRUNCATE)");
    target.close();
    target = undefined;
    assert.equal(await digestFile(source), sourceHash, "Source changed during import");
    const verified = new StateDatabase({ filePath: stagedPath, mode: "read-only" });
    verified.integrityCheck();
    verified.close();
    // Atomic no-clobber publication; an existing unrelated output is never overwritten.
    if (existsSync(`${output}.report.json`)) throw new Error("Output report already exists");
    const outputHash = await digestFile(stagedPath);
    writeFileSync(
      `${output}.report.json`,
      JSON.stringify({ ...report, outputHash }, null, 2) + "\n",
      { flag: "wx", mode: 0o600 },
    );
    try {
      linkSync(stagedPath, output);
    } catch (error) {
      rmSync(`${output}.report.json`);
      throw error;
    }
    return report;
  } finally {
    target?.close();
    legacy.close();
    expected.close();
    if (staging) rmSync(staging, { recursive: true, force: true });
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [source, output] = process.argv.slice(2);
  if (!source || !output || process.argv.length !== 4)
    throw new Error(
      "Usage: node scripts/migration/import-0160-history.mjs INACTIVE_BACKUP NEW_OUTPUT",
    );
  const report = await importHistory(source, output);
  console.log(JSON.stringify(report, null, 2));
}
