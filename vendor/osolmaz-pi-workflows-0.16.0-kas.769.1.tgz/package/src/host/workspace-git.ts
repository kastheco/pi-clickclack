import { execFileSync } from "node:child_process";
import { realpathSync, statSync } from "node:fs";
import path from "node:path";
import type { ChangedFile, ChangedFiles } from "../state/workspace-evidence.js";

export type WorkspaceGitReceipt = {
  schema: "pi-workflows.workspace-git.v1";
  root: string;
  gitDirectory: string;
  rootIdentity: string;
  gitIdentity: string;
  baseRevision: string;
  attribution: ChangedFiles["attribution"];
};

// Metadata only. No shell, external diff driver, textconv, hooks, or inherited Git redirection.
function git(root: string, args: string[]): string {
  const env = Object.fromEntries(
    Object.entries(process.env).filter(([key]) => !key.startsWith("GIT_")),
  );
  return execFileSync("git", ["--no-optional-locks", "-c", "core.fsmonitor=false", ...args], {
    cwd: root,
    env: {
      ...env,
      GIT_CONFIG_NOSYSTEM: "1",
      GIT_CONFIG_GLOBAL: "/dev/null",
      GIT_TERMINAL_PROMPT: "0",
    },
    encoding: "utf8",
    timeout: 2_000,
    maxBuffer: 2_000_000,
    stdio: ["ignore", "pipe", "pipe"],
  });
}

function directoryIdentity(directory: string): string {
  const stat = statSync(directory, { bigint: true });
  if (!stat.isDirectory()) throw new Error("Workspace identity is not a directory");
  return `${stat.dev}:${stat.ino}`;
}

function identity(
  root: string,
): Pick<WorkspaceGitReceipt, "gitDirectory" | "rootIdentity" | "gitIdentity"> {
  if (!path.isAbsolute(root) || realpathSync(root) !== root)
    throw new Error("Invalid workspace root");
  if (git(root, ["rev-parse", "--show-toplevel"]).trim() !== root)
    throw new Error("Workspace root changed");
  const gitDirectory = realpathSync(git(root, ["rev-parse", "--absolute-git-dir"]).trim());
  return {
    gitDirectory,
    rootIdentity: directoryIdentity(root),
    gitIdentity: directoryIdentity(gitDirectory),
  };
}

/** Refuse unsafe/secret names rather than emitting paths that cannot enter the operator contract. */
export function operatorFilePath(value: string): boolean {
  if (
    !value ||
    value.length > 1024 ||
    /[\p{Cc}\p{Cf}\\\ufffd]/u.test(value) ||
    path.posix.isAbsolute(value) ||
    /^[A-Za-z]:/.test(value)
  )
    return false;
  const parts = value.split("/");
  if (parts.some((part) => !part || part === "." || part === "..")) return false;
  return !parts.some(
    (part) =>
      /^(?:\.git|\.ssh|\.gnupg|\.aws|\.env(?:\..*)?|credentials(?:\..*)?|secrets?(?:\..*)?|id_(?:rsa|ed25519|ecdsa)(?:\..*)?)$/i.test(
        part,
      ) || /\.(?:pem|key|p12|pfx)$/i.test(part),
  );
}

const changes: Record<string, ChangedFile["change"]> = {
  A: "added",
  M: "modified",
  D: "deleted",
  R: "renamed",
  C: "copied",
  T: "type_changed",
  U: "unmerged",
};

function tracked(root: string, base: string): ChangedFile[] {
  const tokens = git(root, [
    "diff",
    "--no-ext-diff",
    "--no-textconv",
    "--name-status",
    "-z",
    "--find-renames",
    "--ignore-submodules=dirty",
    base,
    "--",
  ]).split("\0");
  tokens.pop();
  const entries: ChangedFile[] = [];
  for (let index = 0; index < tokens.length;) {
    const code = tokens[index++]!;
    const change = changes[code[0]!];
    const first = tokens[index++];
    if (!change || first === undefined) throw new Error("Invalid Git metadata");
    if (change === "renamed" || change === "copied") {
      const next = tokens[index++];
      if (next === undefined) throw new Error("Invalid Git rename metadata");
      entries.push({ path: next, oldPath: first, change });
    } else entries.push({ path: first, change });
  }
  return entries;
}

function metadata(root: string, base: string): ChangedFile[] {
  const entries = tracked(root, base);
  for (const name of git(root, ["ls-files", "--others", "--exclude-standard", "-z"])
    .split("\0")
    .filter(Boolean)) {
    entries.push({ path: name, change: "untracked" });
  }
  const byPath = new Map(entries.map((entry) => [entry.path, entry]));
  for (const name of git(root, ["ls-files", "--unmerged", "--format=%(path)", "-z"])
    .split("\0")
    .filter(Boolean)) {
    byPath.set(name, { path: name, change: "unmerged" });
  }
  return [...byPath.values()].sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
}

export function prepareWorkspaceGit(
  root: string,
  baseRevision: string,
): WorkspaceGitReceipt | null {
  try {
    if (!/^(?:[0-9a-f]{40}|[0-9a-f]{64})$/.test(baseRevision)) return null;
    const directories = identity(root);
    git(root, ["cat-file", "-e", `${baseRevision}^{commit}`]);
    git(root, ["merge-base", "--is-ancestor", baseRevision, "HEAD"]);
    const dirty = metadata(root, baseRevision).length > 0;
    return {
      schema: "pi-workflows.workspace-git.v1",
      root,
      ...directories,
      baseRevision,
      attribution: dirty ? "includes-preexisting-changes" : "clean-baseline",
    };
  } catch {
    return null;
  }
}

export function collectWorkspaceGit(receipt: WorkspaceGitReceipt): ChangedFiles | null {
  try {
    const directories = identity(receipt.root);
    if (
      directories.gitDirectory !== receipt.gitDirectory ||
      directories.rootIdentity !== receipt.rootIdentity ||
      directories.gitIdentity !== receipt.gitIdentity
    )
      return null;
    if (!/^(?:[0-9a-f]{40}|[0-9a-f]{64})$/.test(receipt.baseRevision)) return null;
    const all = metadata(receipt.root, receipt.baseRevision);
    const safe = all.filter(
      (entry) =>
        operatorFilePath(entry.path) &&
        (entry.oldPath === undefined || operatorFilePath(entry.oldPath)),
    );
    // 500 entries/512 KiB snapshot ceiling from the external snapshot contract.
    const entries: ChangedFile[] = [];
    let bytes = 2;
    for (const entry of safe) {
      bytes += Buffer.byteLength(JSON.stringify(entry)) + (entries.length > 0 ? 1 : 0);
      if (entries.length === 500 || bytes > 256 * 1024) break;
      entries.push(entry);
    }
    const truncated = entries.length < all.length;
    return {
      source: "host-git",
      basis: "cumulative-since-base",
      baseRevision: receipt.baseRevision,
      attribution: receipt.attribution,
      complete: !truncated,
      truncated,
      entries,
    };
  } catch {
    return null;
  }
}
